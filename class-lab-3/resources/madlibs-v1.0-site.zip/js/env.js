var API_URL_STR = "http://APIELB:80/" + "get_random_word" + "/",
	SAVE_API_URL_STR = "http://SaveELB:80/" + "save_paragraph" + "/";
